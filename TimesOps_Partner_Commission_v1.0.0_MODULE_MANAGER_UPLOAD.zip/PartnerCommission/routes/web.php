<?php
use Illuminate\Support\Facades\Route;
use TimesOps\Modules\PartnerCommission\Http\Controllers\PartnerCommissionController as C;
Route::middleware('web')->group(function(){
 Route::prefix('owner/commercial/partner-commission')->name('partner_commission.owner.')->group(function(){
  Route::get('/',[C::class,'index'])->name('index');
  Route::post('/settings',[C::class,'settings'])->name('settings');
  Route::post('/partners',[C::class,'createPartner'])->name('partners.create');
  Route::post('/partners/{id}',[C::class,'updatePartner'])->whereNumber('id')->name('partners.update');
  Route::post('/assignments',[C::class,'assignCompany'])->name('assignments.create');
  Route::post('/assignments/{id}/end',[C::class,'endAssignment'])->whereNumber('id')->name('assignments.end');
  Route::post('/sync',[C::class,'sync'])->name('sync');
  Route::post('/commissions/{id}/approve',[C::class,'approve'])->whereNumber('id')->name('commissions.approve');
  Route::post('/commissions/{id}/reverse',[C::class,'reverse'])->whereNumber('id')->name('commissions.reverse');
  Route::post('/approve-all',[C::class,'approveAll'])->name('approve_all');
  Route::post('/payouts',[C::class,'recordPayout'])->name('payouts.create');
 });
 Route::prefix('partner-network')->name('partner_commission.portal.')->group(function(){
  Route::get('/r/{code}',[C::class,'referral'])->name('referral');
  Route::get('/login',[C::class,'portalLogin'])->name('login');
  Route::post('/login',[C::class,'portalAuthenticate'])->name('authenticate');
  Route::get('/dashboard',[C::class,'portalDashboard'])->name('dashboard');
  Route::post('/password',[C::class,'portalPassword'])->name('password');
  Route::post('/logout',[C::class,'portalLogout'])->name('logout');
 });
});