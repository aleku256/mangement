<?php
namespace TimesOps\Modules\PartnerCommission;
use Illuminate\Support\ServiceProvider;
use TimesOps\Modules\PartnerCommission\Http\Middleware\PartnerCommissionMiddleware;
class PartnerCommissionServiceProvider extends ServiceProvider {
 public function boot(): void {
  $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
  $this->loadViewsFrom(__DIR__.'/../resources/views','timesops-partner-commission');
  try{$this->app['router']->pushMiddlewareToGroup('web',PartnerCommissionMiddleware::class);}catch(\Throwable $e){}
 }
}