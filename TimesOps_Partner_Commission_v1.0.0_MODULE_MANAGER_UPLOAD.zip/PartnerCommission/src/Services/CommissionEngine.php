<?php
namespace TimesOps\Modules\PartnerCommission\Services;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
class CommissionEngine {
 public function ready():bool{foreach(['partner_commission_partners','partner_commission_assignments','partner_commission_payment_events','partner_commission_ledger'] as $t)if(!Schema::hasTable($t))return false;return true;}
 public function companyTable():?string{return Schema::hasTable('companies')?'companies':(Schema::hasTable('tenants')?'tenants':null);}
 public function sync():array{
  if(!$this->ready())return['created'=>0,'reversed'=>0,'sources'=>[]];
  $created=0;$reversed=0;$sources=[];
  if(Schema::hasTable('timesops_stripe_paid_invoices')){
   $sources[]='timesops_stripe_paid_invoices';
   foreach(DB::table('timesops_stripe_paid_invoices')->orderBy('created_at')->get() as $p)
    $created+=$this->settle('stripe_invoice:'.$p->stripe_invoice_id,(int)$p->company_id,((float)$p->amount_minor)/100,strtoupper((string)$p->currency),$p->created_at?:now(),'stripe',(string)$p->stripe_invoice_id,['source'=>'timesops_stripe_paid_invoices']);
  }
  if(Schema::hasTable('saas_payments')){
   $cc=Schema::hasColumn('saas_payments','company_id')?'company_id':(($this->companyTable()==='tenants'&&Schema::hasColumn('saas_payments','tenant_id'))?'tenant_id':null);
   if($cc){
    $sources[]='saas_payments';
    foreach(DB::table('saas_payments')->whereIn('status',['completed','refunded','reversed'])->orderBy('id')->get() as $p){
     $pr=(string)($p->provider_reference??'');$key=str_starts_with($pr,'in_')?'stripe_invoice:'.$pr:'saas_payment:'.$p->id;
     if(in_array((string)$p->status,['refunded','reversed'],true)){$reversed+=$this->reverseSettlement($key,'Payment ledger marked '.$p->status);continue;}
     $created+=$this->settle($key,(int)$p->{$cc},(float)$p->amount,strtoupper((string)$p->currency),$p->paid_at?:$p->created_at?:now(),(string)($p->gateway??'saas_payment'),$pr?:((string)$p->merchant_reference),['source'=>'saas_payments','payment_id'=>(int)$p->id]);
    }
   }
  }
  return compact('created','reversed','sources');
 }
 public function settle(string $key,int $companyId,float $amount,string $currency,$paidAt,string $gateway,string $ref,array $meta=[]):int{
  if($companyId<1||$amount<=0)return 0;$paid=Carbon::parse($paidAt);
  $event=DB::table('partner_commission_payment_events')->where('settlement_key',$key)->first();
  if(!$event){$id=DB::table('partner_commission_payment_events')->insertGetId(['settlement_key'=>$key,'company_id'=>$companyId,'gross_amount'=>round($amount,2),'commissionable_amount'=>round($amount,2),'currency'=>substr($currency?:'USD',0,10),'gateway'=>substr($gateway,0,50),'provider_reference'=>substr($ref,0,190),'status'=>'settled','paid_at'=>$paid,'metadata_json'=>json_encode($meta),'created_at'=>now(),'updated_at'=>now()]);$event=DB::table('partner_commission_payment_events')->where('id',$id)->first();}
  if(DB::table('partner_commission_ledger')->where('payment_event_id',$event->id)->exists())return 0;
  $a=DB::table('partner_commission_assignments')->where('company_id',$companyId)->where('status','active')->where('starts_at','<=',$paid)->where(function($q)use($paid){$q->whereNull('ends_at')->orWhere('ends_at','>=',$paid);})->orderByDesc('starts_at')->orderByDesc('id')->first();
  if(!$a)return 0;$p=DB::table('partner_commission_partners')->where('id',$a->partner_id)->where('status','active')->first();if(!$p||!$this->eligible($p,$a,$paid))return 0;
  $rate=$a->commission_rate_override!==null?(float)$a->commission_rate_override:(float)$p->commission_rate;$comm=round((float)$event->commissionable_amount*$rate/100,2);if($comm<=0)return 0;
  DB::table('partner_commission_ledger')->insert(['partner_id'=>$p->id,'company_id'=>$companyId,'assignment_id'=>$a->id,'payment_event_id'=>$event->id,'rate'=>$rate,'commission_amount'=>$comm,'currency'=>$event->currency,'status'=>'pending','earned_at'=>$paid,'created_at'=>now(),'updated_at'=>now()]);
  return 1;
 }
 private function eligible(object $p,object $a,Carbon $paid):bool{
  $m=(string)$p->commission_mode;$s=Carbon::parse($a->starts_at);
  if($m==='one_time')return !DB::table('partner_commission_ledger')->where('assignment_id',$a->id)->where('status','!=','reversed')->exists();
  if($m==='12_months')return $paid->lte($s->copy()->addMonthsNoOverflow(12));
  if($m==='24_months')return $paid->lte($s->copy()->addMonthsNoOverflow(24));
  return true;
 }
 public function reverseSettlement(string $key,string $reason):int{
  $e=DB::table('partner_commission_payment_events')->where('settlement_key',$key)->first();if(!$e)return 0;
  DB::table('partner_commission_payment_events')->where('id',$e->id)->update(['status'=>'reversed','updated_at'=>now()]);
  $rows=DB::table('partner_commission_ledger')->where('payment_event_id',$e->id)->where('status','!=','reversed')->get();
  foreach($rows as $r)DB::table('partner_commission_ledger')->where('id',$r->id)->update(['status'=>'reversed','reversal_amount'=>$r->commission_amount,'reversal_reason'=>$reason,'reversed_at'=>now(),'updated_at'=>now()]);
  return $rows->count();
 }
 public function captureReferral(string $code):bool{return DB::table('partner_commission_partners')->where('referral_code',strtoupper($code))->where('status','active')->exists();}
 public function assignReferralEmail(string $code,string $email):bool{
  if(!$this->ready()||!Schema::hasTable('users')||!Schema::hasColumn('users','company_id'))return false;
  $p=DB::table('partner_commission_partners')->where('referral_code',strtoupper($code))->where('status','active')->first();if(!$p)return false;
  $u=DB::table('users')->whereRaw('LOWER(email)=?',[strtolower($email)])->whereNotNull('company_id')->orderBy('id')->first();if(!$u||(int)$u->company_id<1)return false;
  if(DB::table('partner_commission_assignments')->where('company_id',$u->company_id)->where('status','active')->exists())return false;
  DB::table('partner_commission_assignments')->insert(['partner_id'=>$p->id,'company_id'=>$u->company_id,'starts_at'=>now(),'status'=>'active','attribution_source'=>'referral_link','referral_code'=>$p->referral_code,'notes'=>'Automatically attributed from referral session.','created_at'=>now(),'updated_at'=>now()]);
  return true;
 }
}