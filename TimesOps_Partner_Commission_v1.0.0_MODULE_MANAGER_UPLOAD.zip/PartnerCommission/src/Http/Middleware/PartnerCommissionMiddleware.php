<?php
namespace TimesOps\Modules\PartnerCommission\Http\Middleware;
use Closure;use Illuminate\Http\Request;use Illuminate\Support\Facades\DB;
use TimesOps\Modules\PartnerCommission\Services\CommissionEngine;
class PartnerCommissionMiddleware{
 public function handle(Request $r,Closure $next){
  $e=app(CommissionEngine::class);
  if($e->ready()&&$r->isMethod('get')&&$r->filled('ref')){$c=strtoupper(trim((string)$r->query('ref')));if($e->captureReferral($c)){$r->session()->put('partner_commission_ref_code',$c);$r->session()->put('partner_commission_ref_at',now()->timestamp);}}
  $path=trim($r->path(),'/');$email=null;$code=(string)$r->session()->get('partner_commission_ref_code','');
  if($e->ready()&&$r->isMethod('post')&&$code!==''&&preg_match('#(?:^|/)(signup|register)$#i',$path))$email=trim((string)$r->input('email',''));
  $resp=$next($r);
  if($email&&filter_var($email,FILTER_VALIDATE_EMAIL)){try{$days=(int)(DB::table('partner_commission_settings')->where('id',1)->value('referral_window_days')?:30);$ts=(int)$r->session()->get('partner_commission_ref_at',0);if($ts>=now()->subDays(max(1,$days))->timestamp&&$e->assignReferralEmail($code,$email))$r->session()->forget(['partner_commission_ref_code','partner_commission_ref_at']);}catch(\Throwable $x){}}
  if($e->ready()&&(str_contains($path,'webhook')||str_contains($path,'billing')||str_contains($path,'subscription')||str_contains($path,'payment')||str_starts_with($path,'owner/commercial/partner-commission')||str_starts_with($path,'partner-network/dashboard')))try{$e->sync();}catch(\Throwable $x){}
  return $resp;
 }
}